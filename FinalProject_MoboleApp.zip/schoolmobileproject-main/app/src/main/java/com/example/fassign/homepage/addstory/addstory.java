package com.example.fassign.homepage.addstory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fassign.R;

public class addstory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addstory);
    }
}