package com.example.fassign.homepage.viewstory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fassign.R;

public class viewstory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewstory);
    }
}