package com.example.fassign.profile.changepassword;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fassign.R;

public class changepassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepassword);
    }
}